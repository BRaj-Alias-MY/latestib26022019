import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReviewskillsComponent } from './reviewskills.component';

describe('ReviewskillsComponent', () => {
  let component: ReviewskillsComponent;
  let fixture: ComponentFixture<ReviewskillsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReviewskillsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewskillsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
