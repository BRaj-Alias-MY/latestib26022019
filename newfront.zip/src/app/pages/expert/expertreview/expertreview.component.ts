import { Component, OnInit } from '@angular/core';
import { ExpertService } from '../services/expert.service';
import { Router } from '@angular/router';
import { ReviewskillsComponent } from '../../masters/reviewskills/reviewskills.component';
import { Feedback } from '../services/feedback';
import { Options } from 'ng5-slider';
import { ValidationService } from '../../../services/validation.service';
@Component({
  selector: 'app-expertreview',
  templateUrl: './expertreview.component.html',
  styleUrls: ['./expertreview.component.css']
})
export class ExpertreviewComponent implements OnInit {
  com: any;
  app: any;
  know: any;
  result: any;
  communication: any = 0;
  object = {};
  data1: Options = {
    floor: 0,
    ceil: 10
  };

  appereance: any = 0;
  data2: Options = {
    floor: 0,
    ceil: 10
  };

  knowledge: any = 0;
  data3: Options = {
    floor: 0,
    ceil: 10
  };
  reviewId = localStorage.getItem('reviewId');
  data = [];
  videoResponse = [];
  feedback: any;
  rating: any;
  id: any;
  feed: Feedback;
  constructor(private route: Router, private api: ExpertService) {
      this.feed = new Feedback();
  }
  ngOnInit() {
    this.getQuestions();
  }
  getQuestions() {
    this.api.get_interviewQuestions(this.reviewId).subscribe(
      resp => {
        console.log(resp);
        this.data = resp;
      },
      err => console.log(err)
    );
  }
  addreview(value) {
    this.id = value;
    //alert(value);
    // this.route.navigate(['/main/expertreview/', this.reviewId]);
    this.api.getInterviewById(value).subscribe(resp => {this.videoResponse = resp; console.log(resp);  }, err => console.log(err));
  }
  onSubmit(myform) {
   // alert(this.id);
    this.feed.review = myform.value['reviewtext'];
    this.feed.rating = myform.value['rating_new'];
    this.feed.id = this.id;
    console.log(this.feed);
    this.api.saveReview(this.feed, this.feed.id).subscribe(resp => {console.log(resp); }, err => console.log(err));


  }
  formSubmit(mydata) {

    this.com = mydata['com'];
    this.app = mydata['app'];
    this.know = mydata['know'];
    this.result = mydata['result'];
    //alert('hi');
    this.object = { 'reportFeedback': [
      {'reportPerameterId': 1, 'review': this.com, 'rating': this.communication},
      {'reportPerameterId': 2, 'review': this.app, 'rating': this.appereance},
      {'reportPerameterId': 3, 'review': this.know, 'rating': this.knowledge}
    ],
    'feedback': this.result
 };
  this.api.postReview(this.object, this.reviewId).subscribe(resp=>{console.log(resp)}, err=>console.log(err));




  }
}