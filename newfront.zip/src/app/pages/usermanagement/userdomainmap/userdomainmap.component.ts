import { Component, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Validators } from '@angular/forms';
import Swal from 'sweetalert2/dist/sweetalert2.js'
import {UsersService} from '../services/users.service';
import { ValidationService } from '../../../services/validation.service';
import { GridOptions } from 'ag-grid-community';
import { ChildMessageRenderer } from '../../../childmessagerender.component';



@Component({
  selector: 'app-userdomainmap',
  templateUrl: './userdomainmap.component.html',
  styleUrls: ['./userdomainmap.component.css']
})
export class UserdomainmapComponent implements OnInit {
  update;
	items;
	lenght;
	btn_update = 'Update';
	btn_add = 'Add';
	access;
  IsForUpdate: boolean = false;
  newItem: any = {};
	updatedItem;
	btn_name: string;
	current_page: number;
	start_record: number;
	pages;
	total_records: number;
	grid_tab;
	sh_add: boolean;
	togel_name: string;
	view_item: any;
	private gridOptions: GridOptions;
	private gridApi;
	private gridColumnApi;

	private columnDefs;
	private rowData;
	private context;
	private frameworkComponents;

  constructor(private fb: FormBuilder, private route: Router, private api: UsersService) {
    this.gridOptions = <GridOptions>{
      paginationNumberFormatter: function(params) {
        return '[' + params.value.toLocaleString() + ']';
      },
    };
    this.columnDefs = [
      {headerName: 'Name', field: 'fname' },
      {headerName: 'Phone', field: 'phone' },
      {headerName: 'E-mail', field: 'email' },
      //{headerName: 'ID', field: 'id', hide:true},
      {
          headerName: "Action",
          cellRenderer: "childMessageRenderer",
          colId: "params",
          value:"id"
  
     }
  ];
    this.frameworkComponents = {
      childMessageRenderer: ChildMessageRenderer
    };
    this.context = { componentParent: this };
   }
  roles;
  domain;
  subdomain;
  selectedDevice;
  usergroups;
  organization;
  ngOnInit() {
    this.btn_name = 'Save';
    this.api.get_roles().subscribe(res=> this.roles = res.data);
    this.api.get_domain().subscribe(res=> this.domain = res.data);
    this.api.get_user_groups().subscribe(res=> this.usergroups = res.data);
    this.api.get_organization().subscribe(res=> this.organization = res.data);
    this.grid_tab = [];
		this.sh_add = false;
    this.togel_name = 'Add';
    this.access = {addAccess: 0, editAccess: 0,deleteAccess:0,gridAccess:0};

    this.grid();

   }

   userdomainForm = this.fb.group({
		id:[],
    fname: ['',ValidationService.alphaValidator],
    mname: ['',ValidationService.alphaValidator],
    lname: ['',ValidationService.alphaValidator],
    email: ['',ValidationService.emailValidator],
    phone: ['',ValidationService.numericValidator],
    gender: ['',ValidationService.alphaValidator],
    organization:[''],
    rolesID: [''],
    domainid: [''],
    subdomain: [''],
    usergroup: ['']
    });


    onGridReady(params) {
      this.gridApi = params.api;
      this.gridColumnApi = params.columnApi;
  
      params.api.sizeColumnsToFit();
    }
  
    add_togel() {
      this.sh_add = this.sh_add ? false : true;
      this.togel_name = this.togel_name == 'Add' ? 'Close' : 'Add';
      this.userdomainForm.patchValue({ fname: '',mname: '',lname: '',email: '',phone: '',gender: '',organization: '',rolesID: '',domainid: '',subdomain: '',usergroup:''});
   }

    onChange($event) {
      this.api.get_subdomain(this.selectedDevice).subscribe(res=> this.subdomain = res.data);
      this.userdomainForm.patchValue({ subdomain: '' });
     }
     methodFromParentEdit(cell,valls) {
      // Swal("Edit");
       console.log(valls.id);
       this.EditItem(valls.id)
       }
       EditItem(item_id)
       {
      // console.log(item_id);
       this.sh_add = true;
       this.togel_name = 'Close';
       this.btn_name = 'Update';
       this.userdomainForm.patchValue(this.get_item_data_with_id(item_id));
      // this.organization= this.get_item_data_with_id(item_id).organization_campuses;
     //console.log( this.organization);
       }
       get_item_data_with_id(item_id){
      for(let i=0;i<this.grid_tab.length;i++){
        if(this.grid_tab[i].id==item_id){
        return this.grid_tab[i];
        }
      }
      }
     
       methodFromParentView(cell,valls) {
       // Swal("View");
       console.log(valls);
       this.ViewItem(valls.id)
       }
    
       ViewItem(item_id)
       {
       this.view_item.push(this.get_item_data_with_id(item_id));
       //console.log(this.view_item);
       this.sh_add = false;
       this.togel_name = 'Add';
       }
     
       back_view(){
       this.view_item = [];
       }
     
    onSubmit(){
      console.log(this.userdomainForm.value);
      this.api.save_userdomain(this.userdomainForm.value).subscribe((res) => {
				if (res.status) {
					// this.grid();
          Swal.fire('Success..', 'Record insert/updated successfully.', 'success');
          this.userdomainForm.patchValue({ fname: '',mname: '',lname: '',email: '',phone: '',gender: '',organization: '',rolesID: '',domainid: '',subdomain: '',usergroup:'' });
          this.grid(); 
					// this.clear_fields();
				} else {
					//this.loading.hide();
					Swal.fire('Oops...', 'Something went wrong!', 'error');
				}
			});
    }

    grid(){
      this.api.getusers().subscribe(data => {
        this.access = data.access;
        if (this.access && this.access.gridAccess) {
          this.grid_tab = data.data;
        }
        this.sh_add = false;
        this.togel_name = 'Add';
        this.btn_name = 'Save';
        //this.loading.hide();
        this.view_item = [];
        }); 
     }


}
